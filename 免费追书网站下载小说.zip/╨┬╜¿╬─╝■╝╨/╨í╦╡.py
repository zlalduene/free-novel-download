import re
import os
import threading
import tkinter as tk
from tkinter import messagebox
import requests

from lxml import etree


def validate_filename(filename):
    pattern = r'[\\/:*?"<>|]'
    return re.sub(pattern, '_', filename)


def download_chapter(link, name, folder, header, event):
    response = requests.get(url=link, headers=header)
    response.encoding = response.apparent_encoding  # 请求response的编码方式
    content = response.text
    tree = etree.HTML(content)

    p_list = tree.xpath('//div[@class="Readarea ReadAjax_content"]/p')

    with open(os.path.join(folder, name + ".txt"), "a", encoding='utf-8') as fp:
        for p in p_list:
            content = p.xpath('./text()')[0]
            fp.write(content + "\n\n")

    # 发送爬取完成的信号
    event.set()


def get_input():
    try:
        input_text = entry.get()
        if input_text != "":
            folder = './小说'
            if not os.path.exists(folder):
                os.makedirs(folder)

            header = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
            }
            thread_list = []
            event = threading.Event()

            # 创建提示文本标签
            progress_label = tk.Label(window, text="正在爬取...", fg="blue")
            progress_label.pack()

            for i in range(1, 4):
                url = input_text + "Page/" + str(i) + "/"
                response = requests.get(url=url, headers=header)
                response.encoding = response.apparent_encoding
                content = response.text
                tree = etree.HTML(content)

                div_list = tree.xpath('//div[@class="books"]/div[5]/dl/dd')

                for div in div_list:
                    link = "http://m.mianfeizhuishu.com" + div.xpath('./a/@href')[0]
                    name = div.xpath('./a/text()')[0]
                    name = validate_filename(name)

                    # 创建线程并添加到线程列表
                    thread = threading.Thread(target=download_chapter, args=(link, name, folder, header, event))
                    thread.start()
                    thread_list.append(thread)

            # 等待所有线程执行完毕
            for thread in thread_list:
                thread.join()

            # 等待爬取完成的信号
            event.wait()

            # 移除提示文本标签
            progress_label.pack_forget()

            # 数据爬取完成后弹窗通知
            messagebox.showinfo("通知", "数据爬取已完成！")
            window.destroy()
        else:
            messagebox.showerror("错误", "请输入网址！")
    except Exception as e:
        messagebox.showerror("错误", str(e))


if __name__ == "__main__":
    window = tk.Tk()
    window.title("小说下载器")
    window.geometry("300x200")
    window.resizable(0, 0)
    entry = tk.Entry(window)
    entry.pack()
    window.config(bg="white")
    button = tk.Button(window, text="输入网址", command=get_input)
    button.pack()
    window.mainloop()
